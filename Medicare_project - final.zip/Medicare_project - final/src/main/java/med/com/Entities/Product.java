package med.com.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
	 
	@Entity
	@Table(name="product")
	public class Product {
		@Id 
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
	    private String category;
	    private String name;
	    private Long number_of_tablets;
	    private Long price;
	    private String image;   	    

		public void setId(Long id) {
			this.id = id;
		}
		public Long getId() {
			return id;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Long getNumber_of_tablets() {
			return number_of_tablets;
		}
		public void setNumber_of_tablets(Long number_of_tablets) {
			this.number_of_tablets = number_of_tablets;
		}
		public Long getPrice() {
			return price;
		}
		public void setPrice(Long price) {
			this.price = price;
		}
		@Override
		public String toString() {
			return "Product [id=" + id + ", category=" + category + ", image=" + image + ", name=" + name
					+ ", number_of_tablets=" + number_of_tablets + ", price=" + price + "]";
		}
	}
