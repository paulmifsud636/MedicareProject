package med.com.Controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import med.com.Entities.Product;
import med.com.Service.ProductService;

@Controller
public class ProductController {

	@Autowired
	private ProductService prodServ;
	
	@GetMapping("/search")
	public String searchPage() {
		return "search";
	}
	
	@GetMapping("/admin/product_added")
	public String saveProduct(Product product){
		prodServ.save(product);
		return "product_added";
	}	
	
	@GetMapping("/admin/add_product")
	public String addProductPage() {
		return "add_product";
	}
		
	@RequestMapping("/product")
	public String showAllProductList(Model model, @Param("criteria") String criteria){
			List<Product>listProduct = prodServ.listAll(criteria);
			model.addAttribute("listProduct", listProduct);
			model.addAttribute("criteria" , criteria);
			return "product";
	}
	
	@RequestMapping("/post_search")
	public String showProductList(Model model, @Param("criteria") String criteria){
			List<Product>listProduct = prodServ.list(criteria);
			model.addAttribute("listProduct", listProduct);
			model.addAttribute("criteria" , criteria);
			return "search";
	}
	
	@RequestMapping("/antibiotics")
	public String showAntibioticsList(Model model, @Param("criteria") String criteria){
		criteria="Antibiotics";
			List<Product>listProduct = prodServ.listAll(criteria);
			model.addAttribute("listProduct", listProduct);
			model.addAttribute("criteria" , criteria);
			return "antibiotics";
	}
	
	@RequestMapping("/analgesics")
	public String showAnalgesicsList(Model model, @Param("criteria") String criteria){
		criteria="Analgesics";
			List<Product>listProduct = prodServ.listAll(criteria);
			model.addAttribute("listProduct", listProduct);
			model.addAttribute("criteria" , criteria);
			return "analgesics";
	}
	
	@RequestMapping("/antipyretics")
	public String showAntipyreticsList(Model model, @Param("criteria") String criteria){
		criteria="Antipyretics";
			List<Product>listProduct = prodServ.listAll(criteria);
			model.addAttribute("listProduct", listProduct);
			model.addAttribute("criteria" , criteria);
			return "antipyretics";
	}	
	
	@GetMapping("/buy{id}")
	public String buyPage() {
		return "cart";
	}


}
	
	
	

