package med.com.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import med.com.Entities.Admin;
import med.com.Repositories.AdminRepository;

@Controller
public class AdminController {

	@Autowired
	private AdminRepository adminRepo;

	@GetMapping("/admin/admin_login")
	public String adminLoginPage() {
		return "admin_login";
	}
	
	@PostMapping("/admin/add_product")
	public String loginAdmin(Admin admin) {
		List<Admin> admins = adminRepo.findAll();
	    for (Admin other : admins) {
	    	if (other.equals(admin)) {
	            return "add_product";
	            }
	        }
	        return "wrong_entry";
	}
}
	  