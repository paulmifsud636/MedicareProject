package med.com.Controllers;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import med.com.Entities.Item;
import med.com.Service.ProductService;

@Controller
@RequestMapping("cart")
public class CartController {

	@Autowired
	private ProductService prodServ;

		@RequestMapping(method = RequestMethod.GET)
		public String demoTest() {
			return "cart";
		}

		@RequestMapping("/buy/{id}")
		public String buy(@PathVariable("id") int id, ModelMap modelMap, HttpSession session){
			if (session.getAttribute("cart") == null) {
				List<Item> cart = new ArrayList<Item>();
				cart.add(new Item(prodServ.find(id), 1));
				session.setAttribute("cart", cart);
			} 
			else { }
			return "cart";
		}
	}
