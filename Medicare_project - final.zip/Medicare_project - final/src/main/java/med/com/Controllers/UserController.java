package med.com.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import med.com.Entities.Product;
import med.com.Entities.User;
import med.com.Repositories.ProductRepository;
import med.com.Repositories.UserRepository;

@Controller
public class UserController {

	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private ProductRepository prodRepo;
    
    @GetMapping("/logout")
	public String backToMainPage() {
		return "index";
	}

	@GetMapping("/shop")
	public String shoppingPage() {
		return "shop";
	}
    
	@GetMapping("/")
	public String viewHomePage() {
		return "index";
	}
	
	@GetMapping("/about")
	public String aboutPage() {
		return "about";
	}
	
	@GetMapping("/wrong_entry")
	public String error1Page() {
		return "wrong_entry";
	}
	
	@GetMapping("/contact")
	public String contactPage() {
		return "contact";
	}
		
	@GetMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@GetMapping("/register")
	public String RegistrationPage(Model model) {
		model.addAttribute("user", new User());
		return "signup_form";
	}
	
	@PostMapping("/registration")
	public String registerUser(User newUser) {	 
		List<User> users = userRepo.findAll();
		for (User user : users) {
			if (user.equals(newUser)) {
				return "wrong_entry";
	            }
	        }try
	        {
	        userRepo.save(newUser);
	        return "successfully_registered"; 
	        }
	        catch (Exception e)
	        {
	        	return "wrong_entry";
	        }     
	}

	@PostMapping("/login_user")
	public String loginUser(User user) {
		List<User> users = userRepo.findAll();
	    for (User other : users) {
	    	if (other.equals(user)) {
	            return "shop";
	            }
	        }
	        return "/wrong_entry";
	}
	
	   @GetMapping("/products")
	    public List<Product> getAllProducts()
	    {
	        return prodRepo.findAll();
	    }
}
	    
