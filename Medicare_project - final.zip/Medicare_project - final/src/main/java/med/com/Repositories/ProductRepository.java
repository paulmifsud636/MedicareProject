package med.com.Repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import med.com.Entities.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	
		@Query("SELECT DISTINCT p FROM Product p WHERE p.category like %?1%")
		public List<Product>findAll(String criteria);
		
		@Query("SELECT DISTINCT p FROM Product p WHERE p.name like %?1%")
		public List<Product>find(String criteria);
	}

