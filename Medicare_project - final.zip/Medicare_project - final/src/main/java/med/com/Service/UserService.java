package med.com.Service;

import org.springframework.stereotype.Service;

@Service 
public class UserService {

}
