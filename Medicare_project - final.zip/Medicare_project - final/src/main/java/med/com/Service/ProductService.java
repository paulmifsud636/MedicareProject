package med.com.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import med.com.Entities.Product;
import med.com.Repositories.ProductRepository;

	@Service
	public class ProductService {

	@Autowired
	private ProductRepository prodRepo;
	   
	public void save(Product product) {
		prodRepo.save(product);
	}
	
	public List<Product>listAll(String criteria) {
		  if (criteria != null) {
			return prodRepo.findAll(criteria);  
		  }
		  return (List<Product>) prodRepo.findAll();
	 }
	
	public List<Product>list(String criteria) {
		  if (criteria != null) {
			return prodRepo.find(criteria);  
		  }
		  return (List<Product>) prodRepo.findAll();
	 }

	public Product find(long id) {
		return null;
	}
}
